 class Mahasiswa {
    private String nim;
    private String nama;
    private double ipk;  // default 0.0, nanti bisa di-set setelah perhitungan

    public Mahasiswa(String nim, String nama) {
        this.nim = nim;
        this.nama = nama;
        this.ipk = 0.0;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public double getIpk() {
        return ipk;
    }

    public void setIpk(double ipk) {
        this.ipk = ipk;
    }
}