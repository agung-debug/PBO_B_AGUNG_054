import java.util.ArrayList;
import java.util.Scanner;

class MainProgram {

    // ----- Atribut untuk login -----
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "12345";
    private static boolean isLoggedIn = false;

    // ----- Data Mahasiswa disimpan dalam ArrayList -----
    private static ArrayList<Mahasiswa> dataMahasiswa = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Perulangan sampai user berhasil login
        while (!isLoggedIn) {
            System.out.println("=== SILAKAN LOGIN ===");
            System.out.print("Username : ");
            String inputUser = scanner.nextLine();
            System.out.print("Password : ");
            String inputPass = scanner.nextLine();

            // Validasi login
            if (inputUser.equals(USERNAME) && inputPass.equals(PASSWORD)) {
                isLoggedIn = true;
                System.out.println("Login berhasil!\n");
            } else {
                System.out.println("Username/Password salah. Coba lagi.\n");
            }
        }

        // Jika login berhasil, tampilkan menu utama
        boolean running = true;
        while (running) {
            System.out.println("===== MENU UTAMA =====");
            System.out.println("1. Input Data Mahasiswa");
            System.out.println("2. Tampilkan Data Mahasiswa");
            System.out.println("3. Hitung IPK Mahasiswa");
            System.out.println("4. Modul Logic Lain (contoh)");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu [1-5]: ");
            String pilihan = scanner.nextLine();

            switch (pilihan) {
                case "1":
                    menuInputData(scanner);
                    break;
                case "2":
                    menuTampilkanData();
                    break;
                case "3":
                    menuHitungIPK(scanner);
                    break;
                case "4":
                    menuLogicLain(scanner);
                    break;
                case "5":
                    System.out.println("Terima kasih. Program berakhir.");
                    running = false;
                    break;
                default:
                    System.out.println("Pilihan tidak valid.\n");
            }
        }

        scanner.close();
    }

    // -------------------------------------------------------------------------
    // 1. MENU INPUT DATA MAHASISWA
    // -------------------------------------------------------------------------
    private static void menuInputData(Scanner scanner) {
        System.out.println("\n=== INPUT DATA MAHASISWA ===");
        System.out.print("Masukkan NIM  : ");
        String nim = scanner.nextLine();
        System.out.print("Masukkan Nama : ");
        String nama = scanner.nextLine();

        // Tambahkan data ke dalam list
        Mahasiswa mhs = new Mahasiswa(nim, nama);
        dataMahasiswa.add(mhs);

        System.out.println("Data berhasil disimpan!\n");
    }

    // -------------------------------------------------------------------------
    // 2. MENU TAMPILKAN DATA MAHASISWA
    // -------------------------------------------------------------------------
    private static void menuTampilkanData() {
        System.out.println("\n=== DAFTAR MAHASISWA ===");
        if (dataMahasiswa.isEmpty()) {
            System.out.println("Belum ada data.\n");
            return;
        }
        for (int i = 0; i < dataMahasiswa.size(); i++) {
            Mahasiswa m = dataMahasiswa.get(i);
            System.out.println((i + 1) + ". NIM: " + m.getNim() + " | Nama: " + m.getNama()
                    + " | IPK: " + m.getIpk());
        }
        System.out.println();
    }
    // -------------------------------------------------------------------------
    // 3. MENU HITUNG IPK
    // -------------------------------------------------------------------------
    private static void menuHitungIPK(Scanner scanner) {
        System.out.println("\n=== HITUNG IPK ===");
        if (dataMahasiswa.isEmpty()) {
            System.out.println("Belum ada data mahasiswa.\n");
            return;
        }

        // Pilih mahasiswa yang akan dihitung IPK-nya
        menuTampilkanData();
        System.out.print("Pilih nomor mahasiswa untuk dihitung IPK-nya: ");
        int pilihan = Integer.parseInt(scanner.nextLine());

        if (pilihan < 1 || pilihan > dataMahasiswa.size()) {
            System.out.println("Pilihan tidak valid.\n");
            return;
        }

        Mahasiswa m = dataMahasiswa.get(pilihan - 1);

        // Contoh sederhana: minta jumlah matkul lalu input nilai (A=4, B=3, dsb.)
        System.out.print("Masukkan jumlah mata kuliah: ");
        int jumlahMatkul = Integer.parseInt(scanner.nextLine());
        if (jumlahMatkul <= 0) {
            System.out.println("Jumlah mata kuliah tidak valid.\n");
            return;
        }

        double totalNilai = 0;
        for (int i = 1; i <= jumlahMatkul; i++) {
            System.out.print("Nilai angka (0.0 s/d 4.0) untuk matkul ke-" + i + ": ");
            double nilai = Double.parseDouble(scanner.nextLine());
            // Validasi rentang nilai
            if (nilai < 0.0 || nilai > 4.0) {
                System.out.println("Nilai di luar rentang. Dianggap 0.\n");
                nilai = 0.0;
            }
            totalNilai += nilai;
        }
        double ipk = totalNilai / jumlahMatkul;
        m.setIpk(ipk);

        System.out.println("IPK " + m.getNama() + " berhasil dihitung = " + ipk + "\n");
    }

    // -------------------------------------------------------------------------
    // 4. MENU MODUL LOGIC LAIN (CONTOH)
    // -------------------------------------------------------------------------
    private static void menuLogicLain(Scanner scanner) {
        System.out.println("\n=== MODUL LOGIC LAIN ===");
        System.out.println("Contoh: Hitung jumlah karakter dari sebuah string.");
        System.out.print("Masukkan kalimat: ");
        String kalimat = scanner.nextLine();

        int jumlahKarakter = kalimat.length();
        System.out.println("Jumlah karakter (termasuk spasi) = " + jumlahKarakter + "\n");
    }
}