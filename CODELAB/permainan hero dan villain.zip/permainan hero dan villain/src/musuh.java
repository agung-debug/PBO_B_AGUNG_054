class musuh extends Karakter {
    public musuh(String nama, int kesehatan) {
        super(nama, kesehatan);
    }

    @Override
    public void serang(Karakter target) {
        // Menampilkan pesan serangan dengan menggunakan sihir
        System.out.println(getNama() + " menyerang " + target.getNama() + " menggunakan sihir!");
        // Mengurangi 15 poin kesehatan target
        int newKesehatan = target.getKesehatan() - 15;
        target.setKesehatan(newKesehatan);
        // Menampilkan kesehatan terbaru target
        System.out.println("Kesehatan " + target.getNama() + " sekarang: " + target.getKesehatan());
    }
}