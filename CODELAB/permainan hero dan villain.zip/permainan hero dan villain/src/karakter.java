class Karakter {
    private String nama;
    private int kesehatan;

    public Karakter(String nama, int kesehatan) {
        this.nama = nama;
        this.kesehatan = kesehatan;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getKesehatan() {
        return kesehatan;
    }

    public void setKesehatan(int kesehatan) {
        this.kesehatan = kesehatan;
    }

    // Method serang yang nantinya akan dioverride oleh subclass
    public void serang(Karakter target) {
        System.out.println(this.nama + " menyerang " + target.getNama());
    }
}