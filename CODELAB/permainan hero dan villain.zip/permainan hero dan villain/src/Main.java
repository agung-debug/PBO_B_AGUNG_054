import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Membuat objek sesuai spesifikasi
        Karakter karakterUmum = new Karakter("Karakter Umum", 100);
        pahlawan pahlawan = new pahlawan("Brimstone", 150);
        musuh musuh = new musuh("Viper", 200);

        // Menampilkan status awal
        System.out.println("Status Awal:");
        System.out.println(pahlawan.getNama() + " - Kesehatan: " + pahlawan.getKesehatan());
        System.out.println(musuh.getNama() + " - Kesehatan: " + musuh.getKesehatan());
        System.out.println();

        // Simulasi pertarungan
        System.out.println("Pertarungan:");
        // Brimstone menyerang Viper menggunakan pedang
        pahlawan.serang(musuh);
        System.out.println();
        // Viper menyerang Brimstone menggunakan sihir
        musuh.serang(pahlawan);
    }
}




