class pahlawan extends Karakter {
    public pahlawan(String nama, int kesehatan) {
        super(nama, kesehatan);
    }

    @Override
    public void serang(Karakter target) {
        // Menampilkan pesan serangan dengan menggunakan pedang
        System.out.println(getNama() + " menyerang " + target.getNama() + " menggunakan pedang!");
        // Mengurangi 20 poin kesehatan target
        int newKesehatan = target.getKesehatan() - 40;
        target.setKesehatan(newKesehatan);
        // Menampilkan kesehatan terbaru target
        System.out.println("Kesehatan " + target.getNama() + " sekarang: " + target.getKesehatan());
    }
}